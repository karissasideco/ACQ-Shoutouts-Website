# Setup guide

This app has three moving pieces:
1. **Firebase** — the live database (free tier is plenty for this).
2. **GitHub** — where the code lives.
3. **Vercel** — hosts the live website, auto-deploys when you push to GitHub.

Total time: ~15 minutes, no coding required.

---

## 1. Create a Firebase project (~5 min)

1. Go to https://console.firebase.google.com and sign in with a company Google account.
2. Click **Add project** → name it e.g. `acq-shoutouts` → you can disable Google Analytics (not needed) → **Create project**.
3. In the left sidebar, click **Build → Firestore Database** → **Create database** → choose a location close to your team → start in **production mode**.
4. Once created, go to the **Rules** tab and replace the contents with what's in `firestore.rules` in this repo, then **Publish**.
5. Go to **Project settings** (gear icon, top left) → scroll to **Your apps** → click the **</> (Web)** icon → nickname it anything → **Register app**. Don't check "Firebase Hosting."
6. You'll see a `firebaseConfig` object with keys like `apiKey`, `authDomain`, etc. Keep this tab open — you'll need these values in step 3.

## 2. Push this code to GitHub (~3 min)

From inside this project folder, run:

```bash
git init
git add .
git commit -m "Initial commit: live shoutout dashboard"
```

Then create a new **empty** repo on GitHub (no README, no .gitignore — this project already has them): https://github.com/new

GitHub will show you commands like this — run them:

```bash
git remote add origin https://github.com/YOUR-ORG/YOUR-REPO.git
git branch -M main
git push -u origin main
```

## 3. Deploy on Vercel (~5 min)

1. Go to https://vercel.com and sign in (you can use your GitHub account).
2. Click **Add New → Project**, and import the GitHub repo you just pushed.
3. Before clicking Deploy, open **Environment Variables** and add the six values from your Firebase config (step 1.6), named exactly like this:

   | Name | Value (from Firebase) |
   |---|---|
   | `NEXT_PUBLIC_FIREBASE_API_KEY` | `apiKey` |
   | `NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN` | `authDomain` |
   | `NEXT_PUBLIC_FIREBASE_PROJECT_ID` | `projectId` |
   | `NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET` | `storageBucket` |
   | `NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID` | `messagingSenderId` |
   | `NEXT_PUBLIC_FIREBASE_APP_ID` | `appId` |

4. Click **Deploy**. In about a minute you'll get a live URL (e.g. `acq-shoutouts.vercel.app`) — share that with the team.

From now on, every time you push to `main` on GitHub, Vercel redeploys automatically.

### Trying it locally first (optional)

```bash
cp .env.example .env.local   # then paste in your Firebase values
npm install
npm run dev
```

Open http://localhost:3000.

---

## Customizing

Almost everything you'd want to tweak — company values, points per shoutout,
streak rules, daily prompt questions, reward tiers — lives in one file:
**`src/lib/config.ts`**. Open it, edit the arrays/constants, commit, push —
Vercel redeploys automatically.

## Adding login later

Right now anyone with the link can post/view (per your request — trust-based,
internal link only). If you later want to require sign-in (e.g. Google
Workspace accounts only) so points are provably tied to real people:

1. In Firebase Console → **Build → Authentication** → enable **Google** sign-in, restrict to your workspace domain.
2. Tighten `firestore.rules` to require `request.auth != null`.
3. Add Firebase Auth's `signInWithPopup` to the app (ask Claude to wire this up when you're ready — it's a small addition on top of what's here).

## How the streak bonus works

If someone is recognized in each of the last 2 **consecutive calendar weeks**
(configurable via `STREAK_WEEKS_FOR_BONUS` in `config.ts`), their next
shoutout in that streak earns double points (`STREAK_BONUS_MULTIPLIER`). This
is calculated automatically on submit — no manual tracking needed.

## Quarterly recognition

There's no leaderboard page currently — points are tracked and shown per
shoutout on each card, but not aggregated into rankings. If you want a
quarterly recognition view later (top scorers by quarter), that's a small
addition on top of the existing points data — just ask.
