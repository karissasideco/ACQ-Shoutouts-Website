# Shoutouts — Live Recognition Dashboard

An internal website where the team submits, views, and reacts to shoutouts in real time. Every shoutout ties to a company value and earns the recognized person points, which build toward rewards and feed quarterly recognition.

**Live wall** — real-time feed of shoutouts, with emoji reactions and points shown per shoutout.
**Give a shoutout** — simple form: who, what they did, which value, why it mattered.
**Daily prompt** — a rotating value-based question to surface shoutouts people might not think of on their own.
**Streaks** — recognized 2 weeks running? Points double automatically.

See `SETUP.md` for the full setup walkthrough (Firebase + GitHub + Vercel, ~15 minutes).
Edit `src/lib/config.ts` to customize values, points, streak rules, prompts, and rewards.

## Local development

```bash
cp .env.example .env.local   # fill in Firebase config, see SETUP.md
npm install
npm run dev
```

## Tech

Next.js (App Router) + TypeScript + Tailwind + Firebase Firestore (real-time, no server to run).
