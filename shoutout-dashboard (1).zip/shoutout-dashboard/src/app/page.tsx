"use client";

import { useEffect, useState } from "react";
import { subscribeToShoutouts, Shoutout } from "@/lib/shoutouts";
import ShoutoutCard from "@/components/ShoutoutCard";
import PromptBanner from "@/components/PromptBanner";

export default function DashboardPage() {
  const [shoutouts, setShoutouts] = useState<Shoutout[] | null>(null);

  useEffect(() => {
    const unsubscribe = subscribeToShoutouts(setShoutouts);
    return unsubscribe;
  }, []);

  return (
    <div className="mx-auto max-w-3xl px-5 py-10">
      <header className="mb-8">
        <div className="flex items-center gap-2">
          <span className="live-dot h-2 w-2 rounded-full bg-electric-indigo" />
          <span className="font-accent text-xs uppercase tracking-wide text-lavender">
            Live
          </span>
        </div>
        <h1 className="font-heading mt-2 text-3xl text-white">THE SHOUTOUT WALL</h1>
        <p className="mt-2 font-body text-sm text-silver">
          Recognition, as it happens. Every shoutout ties back to one of our values.
        </p>
      </header>

      <div className="mb-8">
        <PromptBanner />
      </div>

      {shoutouts === null && (
        <p className="font-body text-sm text-silver">Loading the wall…</p>
      )}

      {shoutouts !== null && shoutouts.length === 0 && (
        <div className="rounded-2xl border border-dashed border-white/15 p-10 text-center">
          <p className="font-heading text-lg text-white">No shoutouts yet</p>
          <p className="mt-2 font-body text-sm text-silver">
            Be the first one to recognize a teammate today.
          </p>
        </div>
      )}

      <div className="flex flex-col gap-4">
        {shoutouts?.map((shoutout) => (
          <ShoutoutCard key={shoutout.id} shoutout={shoutout} />
        ))}
      </div>
    </div>
  );
}
