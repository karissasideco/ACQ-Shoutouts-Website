"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { COMPANY_VALUES } from "@/lib/config";
import { submitShoutout } from "@/lib/shoutouts";

export default function SubmitPage() {
  const router = useRouter();
  const [fromName, setFromName] = useState("");
  const [toName, setToName] = useState("");
  const [valueKey, setValueKey] = useState(COMPANY_VALUES[0].key);
  const [whatTheyDid, setWhatTheyDid] = useState("");
  const [whyItMattered, setWhyItMattered] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const canSubmit =
    fromName.trim() && toName.trim() && whatTheyDid.trim() && whyItMattered.trim() && !submitting;

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!canSubmit) return;
    setSubmitting(true);
    setError(null);
    try {
      await submitShoutout({
        fromName: fromName.trim(),
        toName: toName.trim(),
        valueKey,
        whatTheyDid: whatTheyDid.trim(),
        whyItMattered: whyItMattered.trim(),
      });
      router.push("/");
    } catch (err) {
      console.error(err);
      setError("Couldn't post that shoutout. Check your connection and try again.");
      setSubmitting(false);
    }
  }

  return (
    <div className="mx-auto max-w-xl px-5 py-10">
      <h1 className="font-heading text-3xl text-white">GIVE A SHOUTOUT</h1>
      <p className="mt-2 font-body text-sm text-silver">
        Takes a minute. It&apos;ll show up on the live wall right after you post it.
      </p>

      <form onSubmit={handleSubmit} className="mt-8 flex flex-col gap-6">
        <Field label="Who are you?">
          <input
            value={fromName}
            onChange={(e) => setFromName(e.target.value)}
            placeholder="Your name"
            className={inputClass}
          />
        </Field>

        <Field label="Who are you recognizing?">
          <input
            value={toName}
            onChange={(e) => setToName(e.target.value)}
            placeholder="Teammate's name"
            className={inputClass}
          />
        </Field>

        <Field label="Which value did they represent?">
          <div className="flex flex-wrap gap-2">
            {COMPANY_VALUES.map((v) => (
              <button
                type="button"
                key={v.key}
                onClick={() => setValueKey(v.key)}
                className={[
                  "font-accent rounded-full border px-4 py-2 text-xs uppercase tracking-wide transition-colors",
                  valueKey === v.key
                    ? "border-transparent text-white"
                    : "border-white/15 text-silver hover:border-white/30 hover:text-white",
                ].join(" ")}
                style={valueKey === v.key ? { backgroundColor: v.color } : undefined}
              >
                {v.label}
              </button>
            ))}
          </div>
        </Field>

        <Field label="What did they do?">
          <textarea
            value={whatTheyDid}
            onChange={(e) => setWhatTheyDid(e.target.value)}
            placeholder="Describe what happened, specifically."
            rows={3}
            className={inputClass}
          />
        </Field>

        <Field label="Why did it matter?">
          <textarea
            value={whyItMattered}
            onChange={(e) => setWhyItMattered(e.target.value)}
            placeholder="What was the impact — on you, the team, or a customer?"
            rows={3}
            className={inputClass}
          />
        </Field>

        {error && <p className="font-body text-sm text-red-400">{error}</p>}

        <button
          type="submit"
          disabled={!canSubmit}
          className="font-accent rounded-full bg-electric-indigo px-6 py-3 text-xs uppercase tracking-wide text-white transition-opacity hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-40"
        >
          {submitting ? "Posting…" : "Post shoutout"}
        </button>
      </form>
    </div>
  );
}

const inputClass =
  "w-full rounded-xl border border-white/15 bg-white/[0.04] px-4 py-3 font-body text-sm text-white placeholder:text-silver/50 outline-none focus:border-electric-indigo transition-colors";

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="flex flex-col gap-2">
      <span className="font-accent text-[11px] uppercase tracking-wide text-lavender">
        {label}
      </span>
      {children}
    </label>
  );
}
