/**
 * ── EDIT THIS FILE TO CUSTOMIZE THE APP ──────────────────────────────────
 * Everything your team will want to tweak lives here: values, points,
 * streak rules, and the daily prompt questions. No other file needs to
 * change for basic customization.
 */

export type ValueKey =
  | "unimpeachable_character"
  | "sincere_candor"
  | "competitive_greatness";

export interface CompanyValue {
  key: ValueKey;
  label: string;
  description: string;
  color: string; // hex, used for the value's tag/badge
}

// Acquisition.com's "Big 3" non-negotiable values.
// Add / remove / rename entries here — the rest of the app reads from this list.
export const COMPANY_VALUES: CompanyValue[] = [
  {
    key: "unimpeachable_character",
    label: "Unimpeachable Character",
    description: "Doing the right thing, especially when no one is watching.",
    color: "#6F00FF", // Electric Indigo
  },
  {
    key: "sincere_candor",
    label: "Sincere Candor",
    description: "Honest, direct feedback given with care.",
    color: "#A08BEC", // Lavender
  },
  {
    key: "competitive_greatness",
    label: "Competitive Greatness",
    description: "The drive to be excellent, and to make everyone around you better.",
    color: "#131628", // Sambucus
  },
];

export function getValue(key: string): CompanyValue | undefined {
  return COMPANY_VALUES.find((v) => v.key === key);
}

// ── Points ───────────────────────────────────────────────────────────────

export const POINTS_PER_SHOUTOUT = 10;

// A person is "on a streak" if they were recognized in each of the last N
// consecutive ISO weeks (including the current week). At STREAK_WEEKS_FOR_BONUS
// weeks in a row, new shoutouts in that streak earn a point multiplier.
export const STREAK_WEEKS_FOR_BONUS = 2;
export const STREAK_BONUS_MULTIPLIER = 2;

// ── Reactions ────────────────────────────────────────────────────────────

export const REACTIONS = [
  { emoji: "👏", key: "clap", label: "Clap" },
  { emoji: "🔥", key: "fire", label: "Fire" },
  { emoji: "❤️", key: "heart", label: "Love it" },
  { emoji: "💯", key: "hundred", label: "100" },
] as const;

export type ReactionKey = (typeof REACTIONS)[number]["key"];

// ── Daily prompts ────────────────────────────────────────────────────────
// One is shown per day (rotated deterministically by date), to nudge people
// toward shoutouts they might not have thought of on their own.

export const DAILY_PROMPTS: string[] = [
  "Who showed Competitive Greatness this week?",
  "Who helped make your job easier today?",
  "Who gave you Sincere Candor that helped you improve?",
  "Who quietly solved a problem before it became a bigger issue?",
  "Who went out of their way to help someone outside their own team?",
  "Who showed Unimpeachable Character when it would've been easy not to?",
  "Who made a tough decision look easy this week?",
  "Who's been consistently reliable lately, even if it hasn't been said out loud?",
  "Who taught you something useful recently?",
  "Who took ownership of a mistake instead of pointing fingers?",
];

export function promptOfTheDay(date: Date = new Date()): string {
  // Deterministic by day-of-year so everyone sees the same prompt on a given day.
  const start = new Date(date.getFullYear(), 0, 0);
  const diff = date.getTime() - start.getTime();
  const dayOfYear = Math.floor(diff / (1000 * 60 * 60 * 24));
  return DAILY_PROMPTS[dayOfYear % DAILY_PROMPTS.length];
}

// ── Rewards (display-only reference list; redemption is tracked manually) ─

export interface Reward {
  points: number;
  label: string;
}

export const REWARDS: Reward[] = [
  { points: 50, label: "ACQ swag item" },
  { points: 100, label: "$25 gift card" },
  { points: 250, label: "$75 gift card" },
  { points: 500, label: "Choose-your-own reward" },
];
