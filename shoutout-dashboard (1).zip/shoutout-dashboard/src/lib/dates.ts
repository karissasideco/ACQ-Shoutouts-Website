/** ISO-8601 week key, e.g. "2026-W27". Weeks run Monday–Sunday. */
export function isoWeekKey(date: Date): string {
  const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  // ISO: Thursday of this week decides the year.
  const dayNum = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  const weekNo = Math.ceil(((d.getTime() - yearStart.getTime()) / 86400000 + 1) / 7);
  return `${d.getUTCFullYear()}-W${String(weekNo).padStart(2, "0")}`;
}

/** Returns the weekKey N weeks before the given date's week. */
export function weekKeyOffset(date: Date, weeksAgo: number): string {
  const d = new Date(date);
  d.setUTCDate(d.getUTCDate() - weeksAgo * 7);
  return isoWeekKey(d);
}

/** Given a set of week keys a person has been recognized in, how many
 * consecutive weeks (counting back from the current week) include a shoutout? */
export function currentStreakWeeks(weekKeys: Set<string>, now: Date = new Date()): number {
  let streak = 0;
  for (let i = 0; ; i++) {
    const key = weekKeyOffset(now, i);
    if (weekKeys.has(key)) {
      streak++;
    } else {
      break;
    }
  }
  return streak;
}

export function quarterKey(date: Date): string {
  const q = Math.floor(date.getMonth() / 3) + 1;
  return `${date.getFullYear()}-Q${q}`;
}

export function formatRelativeTime(date: Date): string {
  const seconds = Math.floor((Date.now() - date.getTime()) / 1000);
  if (seconds < 60) return "just now";
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days < 7) return `${days}d ago`;
  return date.toLocaleDateString();
}
