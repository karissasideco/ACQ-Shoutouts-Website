import {
  addDoc,
  collection,
  onSnapshot,
  orderBy,
  query,
  runTransaction,
  doc,
  Timestamp,
  where,
  getDocs,
} from "firebase/firestore";
import { db } from "./firebase";
import { POINTS_PER_SHOUTOUT, STREAK_WEEKS_FOR_BONUS, STREAK_BONUS_MULTIPLIER, ReactionKey, REACTIONS } from "./config";
import { isoWeekKey, currentStreakWeeks } from "./dates";

export interface Shoutout {
  id: string;
  fromName: string;
  toName: string;
  valueKey: string;
  whatTheyDid: string;
  whyItMattered: string;
  points: number;
  isStreakBonus: boolean;
  streakWeeks: number;
  weekKey: string;
  reactions: Record<ReactionKey, number>;
  createdAt: Date;
}

const SHOUTOUTS_COLLECTION = "shoutouts";

function emptyReactions(): Record<ReactionKey, number> {
  const r: Partial<Record<ReactionKey, number>> = {};
  for (const reaction of REACTIONS) r[reaction.key] = 0;
  return r as Record<ReactionKey, number>;
}

export interface NewShoutoutInput {
  fromName: string;
  toName: string;
  valueKey: string;
  whatTheyDid: string;
  whyItMattered: string;
}

/**
 * Submits a new shoutout. Looks at the recipient's recognition history to
 * determine whether they're on a streak (recognized in each of the last
 * STREAK_WEEKS_FOR_BONUS consecutive weeks including this one) — if so,
 * this shoutout's points are multiplied.
 */
export async function submitShoutout(input: NewShoutoutInput): Promise<Shoutout> {
  const now = new Date();
  const weekKey = isoWeekKey(now);

  // Pull the recipient's past shoutouts to compute their week history.
  const q = query(collection(db, SHOUTOUTS_COLLECTION), where("toName", "==", input.toName));
  const snap = await getDocs(q);
  const pastWeekKeys = new Set<string>(snap.docs.map((d) => d.data().weekKey as string));
  pastWeekKeys.add(weekKey); // include this shoutout's week

  const streakWeeks = currentStreakWeeks(pastWeekKeys, now);
  const isStreakBonus = streakWeeks >= STREAK_WEEKS_FOR_BONUS;
  const points = isStreakBonus ? POINTS_PER_SHOUTOUT * STREAK_BONUS_MULTIPLIER : POINTS_PER_SHOUTOUT;

  const docRef = await addDoc(collection(db, SHOUTOUTS_COLLECTION), {
    ...input,
    points,
    isStreakBonus,
    streakWeeks,
    weekKey,
    reactions: emptyReactions(),
    createdAt: Timestamp.fromDate(now),
  });

  return {
    id: docRef.id,
    ...input,
    points,
    isStreakBonus,
    streakWeeks,
    weekKey,
    reactions: emptyReactions(),
    createdAt: now,
  };
}

/** Live subscription to all shoutouts, newest first. */
export function subscribeToShoutouts(callback: (shoutouts: Shoutout[]) => void): () => void {
  const q = query(collection(db, SHOUTOUTS_COLLECTION), orderBy("createdAt", "desc"));
  return onSnapshot(q, (snapshot) => {
    const shoutouts: Shoutout[] = snapshot.docs.map((d) => {
      const data = d.data();
      return {
        id: d.id,
        fromName: data.fromName,
        toName: data.toName,
        valueKey: data.valueKey,
        whatTheyDid: data.whatTheyDid,
        whyItMattered: data.whyItMattered,
        points: data.points ?? POINTS_PER_SHOUTOUT,
        isStreakBonus: data.isStreakBonus ?? false,
        streakWeeks: data.streakWeeks ?? 0,
        weekKey: data.weekKey,
        reactions: { ...emptyReactions(), ...(data.reactions ?? {}) },
        createdAt: (data.createdAt as Timestamp)?.toDate?.() ?? new Date(),
      };
    });
    callback(shoutouts);
  });
}

/** Atomically increments a reaction count on a shoutout. */
export async function addReaction(shoutoutId: string, reactionKey: ReactionKey): Promise<void> {
  const ref = doc(db, SHOUTOUTS_COLLECTION, shoutoutId);
  await runTransaction(db, async (tx) => {
    const snap = await tx.get(ref);
    if (!snap.exists()) return;
    const current = snap.data().reactions ?? {};
    const next = { ...current, [reactionKey]: (current[reactionKey] ?? 0) + 1 };
    tx.update(ref, { reactions: next });
  });
}
