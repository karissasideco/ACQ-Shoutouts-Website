"use client";

import { useState } from "react";
import { Flame } from "lucide-react";
import type { Shoutout } from "@/lib/shoutouts";
import { getValue, REACTIONS, ReactionKey } from "@/lib/config";
import { addReaction } from "@/lib/shoutouts";
import { formatRelativeTime } from "@/lib/dates";

export default function ShoutoutCard({ shoutout }: { shoutout: Shoutout }) {
  const [pending, setPending] = useState<ReactionKey | null>(null);
  const value = getValue(shoutout.valueKey);

  async function handleReact(key: ReactionKey) {
    setPending(key);
    try {
      await addReaction(shoutout.id, key);
    } finally {
      setPending(null);
    }
  }

  return (
    <article
      className="rise-in rounded-2xl border border-white/10 bg-white/[0.03] p-5"
      style={{ borderLeft: `3px solid ${value?.color ?? "#6f00ff"}` }}
    >
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="font-heading text-base leading-tight text-white">
            {shoutout.toName}
          </p>
          <p className="mt-1 font-body text-xs text-silver">
            from {shoutout.fromName} · {formatRelativeTime(shoutout.createdAt)}
          </p>
        </div>
        <div className="flex flex-col items-end gap-1">
          <span
            className="font-accent whitespace-nowrap rounded-full px-3 py-1 text-[10px] uppercase tracking-wide text-white"
            style={{ backgroundColor: value?.color ?? "#6f00ff" }}
          >
            {value?.label ?? shoutout.valueKey}
          </span>
          {shoutout.isStreakBonus && (
            <span className="font-accent flex items-center gap-1 rounded-full bg-white/10 px-3 py-1 text-[10px] uppercase tracking-wide text-lavender">
              <Flame size={11} className="text-lavender" />
              {shoutout.streakWeeks}-week streak · 2x
            </span>
          )}
        </div>
      </div>

      <p className="mt-4 font-body text-sm leading-relaxed text-white/90">
        {shoutout.whatTheyDid}
      </p>
      <p className="mt-3 font-body text-sm leading-relaxed text-silver">
        <span className="font-accent text-[11px] uppercase tracking-wide text-lavender">
          Why it mattered —{" "}
        </span>
        {shoutout.whyItMattered}
      </p>

      <div className="mt-4 flex items-center justify-between">
        <div className="flex gap-1.5">
          {REACTIONS.map((reaction) => {
            const count = shoutout.reactions[reaction.key] ?? 0;
            return (
              <button
                key={reaction.key}
                onClick={() => handleReact(reaction.key)}
                disabled={pending === reaction.key}
                title={reaction.label}
                className="flex items-center gap-1 rounded-full border border-white/10 bg-white/[0.04] px-2.5 py-1 text-xs transition-transform hover:scale-105 hover:bg-white/10 active:scale-95 disabled:opacity-50"
              >
                <span>{reaction.emoji}</span>
                {count > 0 && <span className="font-accent text-white/70">{count}</span>}
              </button>
            );
          })}
        </div>
        <span className="font-accent text-xs text-electric-indigo">
          +{shoutout.points} pts
        </span>
      </div>
    </article>
  );
}
