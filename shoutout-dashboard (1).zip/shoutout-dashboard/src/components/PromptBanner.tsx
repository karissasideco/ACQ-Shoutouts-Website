import Link from "next/link";
import { Sparkles } from "lucide-react";
import { promptOfTheDay } from "@/lib/config";

export default function PromptBanner() {
  const prompt = promptOfTheDay();

  return (
    <div className="rounded-2xl border border-electric-indigo/30 bg-gradient-to-r from-electric-indigo/20 via-lavender/10 to-transparent p-5">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <Sparkles size={18} className="mt-0.5 shrink-0 text-lavender" />
          <div>
            <p className="font-accent text-[11px] uppercase tracking-wide text-lavender">
              Today&apos;s prompt
            </p>
            <p className="font-heading mt-1 text-lg leading-tight text-white">
              {prompt}
            </p>
          </div>
        </div>
        <Link
          href="/submit"
          className="font-accent shrink-0 rounded-full bg-electric-indigo px-5 py-2.5 text-xs uppercase tracking-wide text-white transition-opacity hover:opacity-90"
        >
          Give a shoutout
        </Link>
      </div>
    </div>
  );
}
